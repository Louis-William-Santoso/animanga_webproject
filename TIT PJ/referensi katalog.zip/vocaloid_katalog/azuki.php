<!DOCTYPE html>
    <head>
        <title>Vocaloid</title>
		<meta charset=”UTF-8″>
        <!-- link -->
        <link rel="stylesheet" href="style/otomachi_una_spicy.css">
        <link rel="shortcut icon" href="Random img/kntkt7.jpg"  type="image/x-icon">
    </head>

<body>	
<!--spry menu bar-->
<div class="navbar">
 <a href="file:///D|/XAMPP/htdocs/TIT PJ/new homepage.php">Home</a>
 <a href="file:///D|/XAMPP/htdocs/TIT PJ/new homepage.php #produk">Our Product</a>
 <a href="file:///D|/XAMPP/htdocs/TIT PJ/new homepage.php #ticketmodal">Contact</a>
 <a href="file:///D|/XAMPP/htdocs/TIT PJ/new homepage.php #nama_klm">About Us</a>
</div>
    
    <!-- image -->
    <table id="gambar">
    <td>
    <div id="gambar_produk"><img src="file:///D|/XAMPP/htdocs/TIT PJ/Vocaloid/AZUKI_300.png" height="540"></div></td>
    <td>
    <h1>Azuki</h1>
    <p>Azuki is a Japanese VOCALOID developed by Internet Co., Ltd. in collaboration with MTK Inc. and was released in July 2016 for the VOCALOID4 engine. A speech bank was also released for Talk Ex; on November 11, 2020, a VOICEROID2 version of such talk bank was announced and released in December. In July 2021, she also had a voicebank release in the Voidol engine.</p>

<p>Una was updated to the VOCALOID6 with AI voicebanks in June 2023. She is voiced by the Japanese voice actress, Aimi Tanaka.</p> 
</td>
</table>

	<!--minecart-->
    <footer>
	<div class="minecart">
    <td id="des"><p style="color:white"> ADD SHOPING CART</p></td>
    <td><button>-</button></td>
    <td></td>
    <td><button>+</button></td>
	</div>
</footer>


    
          